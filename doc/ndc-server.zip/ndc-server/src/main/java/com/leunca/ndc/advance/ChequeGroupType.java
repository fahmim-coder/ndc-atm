package com.leunca.ndc.advance;

public class ChequeGroupType {
    protected String chequeIdentifier;
    protected String customerChequeAmount;
    protected String derivedChequeAmount;
    protected int codelineLength;
    protected String codelineData;
}
