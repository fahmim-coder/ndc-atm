package com.leunca.ndc.advance;

public class CounterfeitNotesTypeData extends NotesTypeData {

	public CounterfeitNotesTypeData(String Id) {
		super("d");
	}
}
