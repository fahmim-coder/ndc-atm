package com.leunca.ndc.advance;

public class Track1Data {

    private final String Identifier = "1";
    private String track1;
    
    public Track1Data(String new_track1) {
    	track1 = new_track1;
    }       

    public String getIdentifier() {
        return Identifier;
    }

    public String getTrack1() {
        return track1;
    }
}
