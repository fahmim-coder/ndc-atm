package com.leunca.ndc.advance;

import java.util.List;

public class BunchChequeDepositType {
    private final String Identifier = "g";
	private int totalChequesToReturn;
    private List<BunchChequeDepositCurrencyType>  bunchChequeDepositCurrency;    
}
