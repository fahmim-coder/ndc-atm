package com.leunca.ndc.advance;

public class SingleChequeDeposit {
	private final String Identifier = "a";
	
	//  Codeline detected.
    //  A value of ‘1’ indicates that a minimum number of codeline character has been detected,
	//  A value of ‘0’ indicates that a codeline has not been detected after all allowed retries.
	
	private String codelineDetected;
	private String codelineValue;
	
	public SingleChequeDeposit(){};
   
}
