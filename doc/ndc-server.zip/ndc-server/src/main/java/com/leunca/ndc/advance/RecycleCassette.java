package com.leunca.ndc.advance;

public class RecycleCassette {
    protected int ndcCassetteType;
    protected int numberOfNotesMovedToRecycleCassette;

    public int getNDCCassetteType() {
        return ndcCassetteType;
    }

    public int getNumberOfNotesMovedToRecycleCassette() {
        return numberOfNotesMovedToRecycleCassette;
    }
}
