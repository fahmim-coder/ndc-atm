package com.leunca.ndc.advance;

public class CoinDispensedFromHopperType {
    private final String Identifier = "f";
    private int[] numberOfCoinDispensedFromHopperType;
    
    public CoinDispensedFromHopperType() {};
}
