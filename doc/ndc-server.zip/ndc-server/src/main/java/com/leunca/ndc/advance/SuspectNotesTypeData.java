package com.leunca.ndc.advance;

public class SuspectNotesTypeData extends NotesTypeData {
	public SuspectNotesTypeData(String Id) {
		super("c");
	}
}
