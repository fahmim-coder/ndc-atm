package com.leunca.ndc.advance;

public class BarcodeData {
    private final String Identifier = "e";
    
    private String barcodeFormatID;
    private String scannedBarcodeData;
    
	public String getIdentifier() {
		return Identifier;
	}

	public String getBarcodeFormatID() {
		return barcodeFormatID;
	}

	public String getScannedBarcodeData() {
		return scannedBarcodeData;
	}
}
