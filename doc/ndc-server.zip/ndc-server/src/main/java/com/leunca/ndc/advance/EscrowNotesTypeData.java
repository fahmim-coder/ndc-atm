package com.leunca.ndc.advance;

public class EscrowNotesTypeData extends NotesTypeData {

	public EscrowNotesTypeData(String Id) {
		super("w");
	}
}
